using UnityEngine;
using DG.Tweening; // DOTween ���ӽ����̽� �߰�

public class TextEffect : MonoBehaviour
{
    void Start()
    {
        transform.DOScale(1.5f, 0.4f).SetLoops(-1, LoopType.Yoyo);
    }
}