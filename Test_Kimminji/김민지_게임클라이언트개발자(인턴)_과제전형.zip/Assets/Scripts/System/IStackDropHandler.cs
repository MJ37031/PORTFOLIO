using UnityEngine;

public interface IStackDropHandler
{
    void OnDrop(GameObject item);
}
