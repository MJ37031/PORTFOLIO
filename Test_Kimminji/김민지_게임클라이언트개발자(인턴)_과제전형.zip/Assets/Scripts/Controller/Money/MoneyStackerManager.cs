// MoneyStackerManager.cs

using UnityEngine;

public class MoneyStackerManager : MonoBehaviour
{
    public static MoneyStackerManager I;

    [Header("������ MoneyStacker")]
    public MoneyStacker takeOutStacker; // ���� �մԿ� �� �״� ��
    public MoneyStacker dineInStacker;  // ���� �Ļ� �մԿ� �� �״� ��

    private void Awake()
    {
        I = this;
    }
    public void AddMoney(CustomerType customerType, int breadCount)
    {
        if (customerType == CustomerType.TakeOut && takeOutStacker != null)
        {
            takeOutStacker.AddMoneyForBread(breadCount);
        }
        else if (customerType == CustomerType.EatingIn && dineInStacker != null)
        {
            dineInStacker.AddMoneyForBread(breadCount);
        }
    }
}