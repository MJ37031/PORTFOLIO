using UnityEngine;

public class Trash : MonoBehaviour
{
    public ParticleSystem cleanEffect;
    public AudioSource cleanSound;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("�÷��̾ �����⸦ �ֿ����ϴ�.");

            ShowCleanEffect();
            cleanSound.PlayOneShot(cleanSound.clip);

            Destroy(gameObject);
        }
    }



    public void ShowCleanEffect(float duration = 1.5f)
    {
        if (cleanEffect != null)
        {
            cleanEffect.Play();

        }
    }
}